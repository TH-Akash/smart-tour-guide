import React from "react";

const Footer = () => {
  return <div>this is footer</div>;
};

export default Footer;
